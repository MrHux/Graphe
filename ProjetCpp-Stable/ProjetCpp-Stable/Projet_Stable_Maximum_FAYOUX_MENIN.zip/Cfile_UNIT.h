#pragma once
#ifndef NDEBUG
#include "stdafx.h"

class Cfile_UNIT
{

public:

	static void TEST_UNIT_parse_file();

};
#endif
