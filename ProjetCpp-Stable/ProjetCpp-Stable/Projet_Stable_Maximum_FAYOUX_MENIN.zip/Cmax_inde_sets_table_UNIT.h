/**
* @file Cmax_inde_sets_table_UNIT.h
*
* \author Paul Fayoux
*
*
*/

#pragma once
#include "stdafx.h"

//! Cmax_inde_sets_table_UNIT Class
class Cmax_inde_sets_table_UNIT
{
public:
	static void TEST_UNIT_Cmax_inde_sets_table_UNIT();

	static void TEST_UNIT_GRTempty_table();

	static void TEST_UNIT_MITenum_max_inde_set();

};

